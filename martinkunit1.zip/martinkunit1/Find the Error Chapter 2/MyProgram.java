public class MyProgram {
    public static void main(String[] args) // Removed Semicolon from example
    { // Corrected bracket
        int a, b, c; // Three Integers -- added semi-colon and changed backslashes to forward slashes
        a = 3; // Added semi-colon
        b = 4; // Added semi-colon
        c = a + b; // Added semi-colon
        System.out.println("The value of c is " + c); // changed single quote to double quote and added space / lowercase c
    } // Corrected bracket
}
